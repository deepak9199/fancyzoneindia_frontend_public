declare module 'magnific-popup';
