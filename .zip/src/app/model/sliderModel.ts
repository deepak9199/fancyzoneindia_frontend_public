export interface SliderModel {
   
    mobile_imageURL: string;
    web_imageURL:string;
  } 