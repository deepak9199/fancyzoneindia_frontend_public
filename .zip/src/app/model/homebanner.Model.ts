export interface HomeBannerModel {
  heading: string;
  subheading1: string;
  subheading2: string;
  imageUrl: string;
}
