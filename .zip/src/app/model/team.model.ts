export interface TeamModel {
    name:string,
    designation:string,
    fbUrl:string,
    imageUrl:string
  }