export interface WorkingModel {
   
   weekday:string,
   sunday:string,
   notice:string,
   website_background:string
  }