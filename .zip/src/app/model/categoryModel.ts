export interface CategoryModel {
    id?: any;
    category: string;
    imageUrl:string;
  } 