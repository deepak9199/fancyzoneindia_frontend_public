export interface ContactModel {
   name:string,
   email:string,
   contact:string,
   subject:string,
   message:string
  } 