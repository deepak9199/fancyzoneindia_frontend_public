export interface SubCategory {
    category: string;
    sub_category: string[];
    imageUrl:string
  }