export interface VarientModel {
   
    size: string;
    price: number;
    sku: string
  }