
export const environment = {
  production: false,
 // Import the functions you need from the SDKs you need


 firebaseConfig : {
  apiKey: "AIzaSyCzctI56ZUVu6Vx-RuTTzXi9j3a1kItF6M",
  authDomain: "fancyzone-1afee.firebaseapp.com",
  projectId: "fancyzone-1afee",
  storageBucket: "fancyzone-1afee.appspot.com",
  messagingSenderId: "173693620812",
  appId: "1:173693620812:web:212c9dfe25e5a9dab19ae9",
  measurementId: "G-XHSWCCF5KE"
  }
}
